<?php
/**
 * Plugin Name: WooCommerce Orders Table
 * Plugin URI: Your Plugin URL
 * Description: Displays WooCommerce orders in a table and allows filtering by date and price.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: Your Website
 * Text Domain: woocommerce-orders-table
 * Domain Path: /languages
 *
 * WC requires at least: 3.0.0
 * WC tested up to: 5.0.0
 */

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Load WooCommerce
if (class_exists('WooCommerce')) {
    // Plugin code goes here
}

function woot_custom_orders_menu() {
    add_menu_page(
        'WP Report',
        'WP Report',
        'manage_options',
        'woot-orders-table',
        'woot_render_orders_table'
    );
}
add_action('admin_menu', 'woot_custom_orders_menu');

function woot_render_orders_table() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Filter form
    echo '<form method="get">';
    echo '<input type="hidden" name="page" value="woot-orders-table">';
    echo '<label for="start_date">Start Date:</label>';
    echo '<input type="date" name="start_date" id="start_date" value="' . esc_attr($_GET['start_date'] ?? '') . '">';
    echo '<label for="end_date">End Date:</label>';
    echo '<input type="date" name="end_date" id="end_date" value="' . esc_attr($_GET['end_date'] ?? '') . '">';
    echo '<label for="min_price">Min Price:</label>';
    echo '<input type="number" step="0.01" name="min_price" id="min_price" value="' . esc_attr($_GET['min_price'] ?? '') . '">';
    echo '<label for="max_price">Max Price:</label>';
    echo '<input type="number" step="0.01" name="max_price" id="max_price" value="' . esc_attr($_GET['max_price'] ?? '') . '">';
    echo '<input type="submit" value="Filter">';
    echo '</form>';

    // Orders table
    $args = array(
        'post_type' => 'shop_order',
        'post_status' => 'wc-completed',
        'posts_per_page' => -1,
        'meta_query' => array(),
    );

    if (!empty($_GET['start_date'])) {
        $args['meta_query'][] = array(
            'key' => '_completed_date',
            'value' => esc_attr($_GET['start_date']),
            'compare' => '>=',
            'type' => 'DATE',
        );
    }

    if (!empty($_GET['end_date'])) {
        $args['meta_query'][] = array(
            'key' => '_completed_date',
            'value' => esc_attr($_GET['end_date']),
            'compare' => '<=',
            'type' => 'DATE',
        );
    }

    if (!empty($_GET['min_price'])) {
        $args['meta_query'][] = array(
            'key' => '_order_total',
            'value' => esc_attr($_GET['min_price']),
            'compare' => '>=',
            'type' => 'DECIMAL',
        );
    }

    if (!empty($_GET['max_price'])) {
        $args['meta_query'][] = array(
            'key' => '_order_total',
            'value' => esc_attr($_GET['max_price']),
            'compare' => '<=',
            'type' => 'DECIMAL',
        );
    }

    $orders = new WP_Query($args);

    if ($orders->have_posts()) {
        echo '<table>';
        echo '<tr><th>Order ID</th><th>Date</th><th>Total</th></tr>';
        while ($orders->have_posts()) {
            $orders->the_post();
            $order = wc_get_order(get_the_ID());
            echo '<tr>';
            echo '<td>' . get_the_ID() . '</td>';
            echo '<td>' . $order->get_date_completed()->date('Y-m-d H:i:s') . '</td>';
            echo '<td>' . wc_price($order->get_total()) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        wp_reset_postdata();
    } else {
        echo 'No orders found.';
    }
}

