<!-- templates/order-table.php -->
<div class="wrap">
    <h1>Order Table</h1>

    <form method="get" action="http://localhost/wpreport/wp-admin/admin.php?page=wootable">
        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" id="start_date" value="<?php echo esc_attr($start_date); ?>">

        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" id="end_date" value="<?php echo esc_attr($end_date); ?>">

        <label for="min_price">Min Price:</label>
        <input type="number" step="0.01" name="min_price" id="min_price" value="<?php echo esc_attr($min_price); ?>">

        <label for="max_price">Max Price:</label>
        <input type="number" step="0.01" name="max_price" id="max_price" value="<?php echo esc_attr($max_price); ?>">

        <input type="submit" class="button" value="Filter">
    </form>

    <table class="widefat">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Total</th>
                <!-- Add more columns if needed -->
            </tr>
        </thead>
        <tbody>
            <?php if ($orders->have_posts()) : ?>
                <?php while ($orders->have_posts()) : $orders->the_post(); ?>
                    <?php
                    $order = wc_get_order(get_the_ID());
                    ?>
                    <tr>
                        <td><?php echo esc_html($order->get_order_number()); ?></td>
                        <td><?php echo esc_html($order->get_date_created()->date('Y-m-d H:i:s')); ?></td>
                        <td><?php echo esc_html($order->get_total()); ?></td>
                        <!-- Add more columns if needed -->
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="3">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
