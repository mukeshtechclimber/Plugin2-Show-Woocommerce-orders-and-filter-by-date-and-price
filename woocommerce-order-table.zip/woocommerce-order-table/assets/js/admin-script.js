jQuery(document).ready(function($) {
    $('form').on('submit', function(e) {
        e.preventDefault();
        var minPrice = $('#min_price').val();
        var maxPrice = $('#max_price').val();
        var date = $('#date').val();
        var url = window.location.href.split('?')[0];

        if (minPrice || maxPrice || date) {
            url += '?';

            if (minPrice) {
                url += 'min_price=' + minPrice + '&';
            }

            if (maxPrice) {
                url += 'max_price=' + maxPrice + '&';
            }

            if (date) {
                url += 'date=' + date + '&';
            }

            url = url.slice(0, -1);
        }

        window.location.href = url;
    });
});
